// -----------------------------------------------------
// Assignment 3
// Question: N/A
// Written by: Sisahga Phimmasone - 40210015
// -----------------------------------------------------

/**
 * @author Sisahga Phimmasone - 40210015
 * COMP 249
 * Assignment #3
 * Due Friday, March 25th, 2022
 */

/**
 * This class handles the exception where there is an attribute missing in the csv file.
 */
public class CSVAttributeMissing extends Exception
{
    public CSVAttributeMissing()
    {
        super("Error: Input row cannot be parsed due to missing information");
    }
    /**
     * 
     * @param str
     */
    public CSVAttributeMissing(String str)
    {
        super(str);
    }
}