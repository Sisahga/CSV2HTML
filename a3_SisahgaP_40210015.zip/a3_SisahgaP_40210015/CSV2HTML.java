import java.util.Scanner;
import java.io.*;

// -----------------------------------------------------
// Assignment 3
// Question: N/A
// Written by: Sisahga Phimmasone - 40210015
// -----------------------------------------------------

/**
 * @author Sisahga Phimmasone - 40210015
 * COMP 249
 * Assignment #3
 * Due Friday, March 25th, 2022
 */

public class CSV2HTML
{
    /**
     * This static method's ultimate goal is to convert CSV files to HTML files. It takes 3 parameters: 1 scanner and 2 printwriters (one for the html file, one for the exceptions log file.)
     * It uses html tags in Strings and seperates values (commas) with the split() method in order to access each cell of the csv file individually.
     * The method makes calls ot exception classes that I wrote such as CSVAttributeMissing and CSVDataMissing to handle specific exceptions.
     * The scanner reads the csv file and the printwriter writes to the html file.
     * @param sc is a scanner that reads a file.
     * @param pw is a printwriter that writes to a file.
     * @param el is a printwriter that writes to the exceptions log file.
     */
    public static void ConvertCSVtoHTML(Scanner sc, PrintWriter pw, PrintWriter el)
    {
        String s = null;
        try
        {
            pw.println("<!Doctype>\n<html>\n<style>\ntable{font-family: arial, sans-serif;border-collapse: collapse;}\ntd,th{border: 1px solid #000000;text-align:left;padding: 8px;}");
            pw.println("tr:nth-child(even) {background-color: #dddddd;}\nspan{font-size:small}\n</style>\n<body>");

            s = sc.nextLine();
            String valuesarr[] = s.split(",");

            pw.println("<table>");
            pw.println("<caption>" + valuesarr[0] + "</caption>");
            
            s = sc.nextLine();

            valuesarr = s.split(",", -1); //goes through all elements of the line and splits everytime there is a "," until the last one.
            pw.println("\t<tr>");

            for (String item : valuesarr)
            {
                if (item.isEmpty() || item.isBlank())
                {
                    sc.close();
                    pw.close();
                    throw new CSVAttributeMissing("\nERROR: In file " + s + ".csv. Missing attribute. File is not converted to HTML.");
                }
            }
            
            for (String item : valuesarr)
            {
                pw.println("\t\t<th>" + item + "</th>");   
            }
            pw.println("\t</tr>");
            
            s = sc.nextLine();
            valuesarr = s.split(",");
            
            while (sc.hasNextLine())
            {
                valuesarr = s.split(",", -1);
                String note[] = s.split(":");
                if (note[0].compareToIgnoreCase("note") == 0)
                {
                    break;
                }
                pw.println("\t<tr>");
                int ctr = 2;
                
                for (String item : valuesarr)
                {
                    ctr++;
                    pw.println("\t\t<td>" + item + "</td>");
                    if (item.isEmpty() || item.isBlank())
                    {
                        throw new CSVDataMissing("\nWARNING: In file" + s + ".csv line " + ctr + " is not converted to HTML: missing data: ICU");
                    }
                }
                pw.println("\t</tr>");
                s = sc.nextLine();
            }
            pw.println("</table>");
            String note[] = s.split(":");
            if (note[0].compareToIgnoreCase("Note") == 0)
            {
                valuesarr = s.split(",");
                pw.println("<span>" + valuesarr[0] + "</span>");
            }
        //Closing html file.
            pw.println("\n</body>\n</html>");

            pw.close();
            sc.close();
            el.close();
        }
        catch (CSVAttributeMissing cam)
        {
            el.println(cam.getMessage());
            System.out.println(cam.getMessage());
            el.close();
            sc.close();
            pw.close();
            System.exit(0);
        }
        catch (CSVDataMissing cdm)
        {
            el.println(cdm.getMessage());
            System.out.println(cdm.getMessage());
            el.close();
            sc.close();
            pw.close();
            System.exit(0);
        }
    }
    
    /**
     * This is the main method. It will open all input and output files according to which one the user desires. The program will ask the user which csv file they want to open/convert to html.
     * It will attempt to open that file. If the file is successfully opened, the program will then ask the user which html file they want to write to and it will try to open that file.
     * After this, the program will make use of the static method above ConvertCSVtoHTML to convert the csv file requested by the user into an html file (the html file the user indicated is where the html
     * code will be written.) After, the program will ask the user to enter the name of the html file that has just been written to in order to display it on the screen. The program the closes.
     * @param args
     */
    public static void main(String[] args) 
    {
    //Welcome message.
        System.out.println("\n------------------------------------------------------------------");
        System.out.println("                  Welcome to Sisahga's Java World                 ");
        System.out.println("------------------------------------------------------------------");
        
        String filename = null;
        String userinput = null;
        Scanner kb = new Scanner(System.in); //Scanner to take input from the user.
        Scanner sc = null; //Scanner to read files.
        PrintWriter pw = null; //PrintWriter to write to the HTML file.
        PrintWriter el = null; //PrintWriter to write to the exception logs file.
        BufferedReader br = null;

    /* --- Opening the input and output streams --- */

    //Trying to open input files.
        System.out.print("\nPlease enter the name of the file that you want to open for reading with its extension: ");
        filename = kb.next();
        try
        {
            sc = new Scanner(new FileInputStream(filename));
            System.out.println("\tInput file " + filename + " was successfully opened.");
        }
        catch(FileNotFoundException e)
        {
            System.out.println("Could not open input file " + filename + " for reading.");
            System.out.println("Please check that the file exists and is readable. This program will terminate after any opened files.");
            System.exit(0);
        }

     //Trying to open/create output files.

        System.out.print("\nPlease enter the name of the html file you wish to write to with its extension: ");
        filename = kb.next();
        try
        {
            pw = new PrintWriter(new FileOutputStream(filename));
            System.out.println("\tHTML file " + filename + " was successfully opened");
        }
        catch(FileNotFoundException e)
        {
            System.out.println("Could not open output file " + filename + " for writing.");
            System.out.println("Please check that the file exists and is readable. This program will terminate after any opened files.");
            sc.close();
            System.exit(0);
        }

    //Exceptions.log
        try
        {
            el = new PrintWriter(new FileOutputStream("Exceptions.log"), true);
            System.out.println("Exceptions.log file was successfully opened");
        }
        catch(FileNotFoundException e)
        {
            System.out.println("Could not open output file Exceptions.log for writing.");
            System.out.println("Please check that the file exists and is readable. This program will terminate after any opened files.");
            pw.close();
            sc.close();
            System.exit(0);
        }
        ConvertCSVtoHTML(sc, pw, el);
        System.out.println("\nYour .csv files have been successfully converted into html files");

    //Displaying the HTML files
        System.out.print("\nPlease enter the name of the html file you wish to display along with its extension: ");
        userinput = kb.next();

        try
        {
            br = new BufferedReader(new FileReader(userinput));
        }
        catch (FileNotFoundException e)
        {
            System.out.println("Could not open file " + userinput + " for reading.");
            System.out.println("Please check that the file exists and is readable.");
            System.out.println("You have one final attempt to enter a valid file name.");
            System.out.print("\nPlease enter the name of the converted html file you wish to display: ");
            userinput = kb.next();
            try
            {
                br = new BufferedReader(new FileReader(userinput));
            }
            catch (FileNotFoundException e1)
            {
                System.out.println("Could not open file " + userinput + ".csv for reading.");
                System.out.println("Please check that the file exists and is readable.");
                System.out.println("You have exhausted all of your attempts.\nThis program will terminate after closing any opened files");
                sc.close();
                pw.close();
                kb.close();
                System.exit(0);
            }
        }
        try
        {
            String s = br.readLine();
            while (s != null)
            {
                System.out.print("\n" + s);
                s = br.readLine();
            }
        }
        catch (IOException ioe)
        {
            System.out.println("Error: An error has occured while trying to read from the " + userinput + " file.");
            System.out.println("Program will terminate after closing any opened files.");
            pw.close();
            sc.close();
            kb.close();
        }

    //Closing message.
        System.out.println("\n\n------------------------------------------------------------------");
        System.out.println("                You are now out of Sisahga's World                ");
        System.out.println("------------------------------------------------------------------");
    }
}