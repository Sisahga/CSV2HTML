// -----------------------------------------------------
// Assignment 3
// Question: N/A
// Written by: Sisahga Phimmasone - 40210015
// -----------------------------------------------------

/**
 * @author Sisahga Phimmasone - 40210015
 * COMP 249
 * Assignment #3
 * Due Friday, March 25th, 2022
 */

/**
 * This class handles the exception where there is missing data in one or more of the cells in the csv file.
 */
public class CSVDataMissing extends Exception{
    
    public CSVDataMissing()
    {
        super("Error: Input row cannot be parsed due to missing information");
    }
    /**
     * 
     * @param str
     */
    public CSVDataMissing(String str)
    {
        super(str);
    }

}
